#include<iostream>
#include <stdexcept>
#include<cstdlib>
#include <cstring>
#include <iomanip>
// import <iostream>;
/* 
 * Author:- Alok Kumar Mishra
 * akmishra_99@yahoo.com
 * Oct 29,2024
 *
*/
using namespace std;

const int MAX_STRING_SIZE = 80;
const unsigned short MAX_RECORD = 100; 




void hexdump(const void* data, size_t size) {
    const unsigned char* p = static_cast<const unsigned char*>(data);
    for (size_t i = 0; i < size; ++i) {
        std::cout << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(p[i]) << " ";
        if ((i + 1) % 16 == 0) {
	     
	     for (int j = i -16; j < i; j++ ) {
	        char pp = char(p[j]);
	        std::cout << " " << pp;
	     }
            std::cout << std::endl;
        }
    }
    std::cout << std::endl;
}
class Student_record_Exception : public std::exception {
public:
    Student_record_Exception(const std::string& message) :  m_error_message(message) {}

    const char* what() const noexcept override {
        return ("Failed to create student_record name exceeded " + m_error_message).c_str();
    }

private:
    std::string m_error_message;
};
typedef struct student_record {

public:
	student_record(int given_id,std::string given_name) 

	{
	    m_id =  given_id;
	    m_name.reserve(MAX_STRING_SIZE);
            if ( m_name.length() < MAX_STRING_SIZE) {
               m_name = given_name.c_str();
	       strcpy(in_char,m_name.c_str());
	    }
            else {
                // throw an exception saying sizeof string has exceeded             
                throw Student_record_Exception("student record length exceeded then maximum allowed");
	    }
	}
	void print_student_record(bool c_style = false) 
	{
		cout << " student id = " << m_id; 
		if (c_style ) 
		    cout << " student name = " <<  in_char << endl;	
		else
		    cout 	<< " student name = " << m_name << " in_char = " << in_char << endl;

	}
private:
	int m_id;
	char in_char[MAX_STRING_SIZE];
	std::string m_name;
} t_student_record;

int main(int argc,char **argv,char **envp) 
{
      unsigned short int student_count = 0; 
      unsigned short int size_of_student_record = sizeof(struct student_record);
      void *memory =  malloc ( sizeof (struct student_record) * MAX_RECORD); 
      int member_size[MAX_RECORD] = { 0 };
      if (!memory) {
          cout << "failed to allocate memory " << endl;
	  exit(1);
       }
       void *memory_beggining = memory; 
       int sum = 0; 
       for (auto i = 0; i <  MAX_RECORD; i++ ) {
           try { 
               t_student_record a_student(i,"Brian_" + std::to_string(i));
	       member_size[i] = sizeof(a_student);

               // now display student record's by traversing memory 
               memcpy((void *) (memory + sum ), (void *) &a_student,sizeof(a_student));
#ifdef DEBUG
               t_student_record *ptr_a_student = (struct student_record *) (memory + sum);               
	       ptr_a_student->print_student_record(false);
               cout << "member[" << i << "] = "  << member_size[i] << endl;
#endif 
	       sum = sum +  member_size[i];
           }
           catch (const Student_record_Exception& e) {
               cerr << e.what() << endl;
               exit(2);
           }
           
       }
       // now display student record's by acessing  memory as array
       // if you want to see memroy dump of allocated memory by using malloc enable following line 
       // hexdump(memory,size_of_student_record * MAX_RECORD);
       t_student_record *ptr_a_student2 = (struct student_record *) (void *) (memory_beggining  );
       for (auto i = 0; i <  MAX_RECORD; i++ ) {
           try {
	       ptr_a_student2[i].print_student_record(true);
           }
           catch (const std::out_of_range& e) {
               cerr << " at i = " << i << endl;
               std::cerr << "Out of range error: " << e.what() << std::endl;

	   }

       }
       return 0;
}
